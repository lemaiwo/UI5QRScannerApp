sap.ui.define(["sap/ui/core/Control", "sap/m/Select", "sap/ui/core/Item"], function (Control, Select, Item) {
    "use strict";
    return Control.extend("be.wl.ScannerApp.control.QRScanner", {
        "metadata": {
            "properties": {
                value: 'string'
            },
            "events": {
                QRCodeScanned: {
                    parameters: {
                        value: {
                            type: "string"
                        }
                    }
                }
            },
            aggregations: {
                _cameraSelection: {
                    type: "sap.m.Select",
                    multiple: false,
                    visibility: "hidden"
                }
            }
        },
        init: function () {
            this.setAggregation("_cameraSelection", new Select({change:this.onChangeCamera.bind(this)}));
        },
        onAfterRendering: function (evt) {
            this.scanner = new Instascan.Scanner({
                video: this.getDomRef().lastElementChild
            });
            this.scanner.addListener('scan', (qrcode) => this.onQRCodeScanned(qrcode));
            Instascan.Camera.getCameras().then(function (cameras) {
                this.cameras=cameras;
                cameras.forEach(function (camera,key) {
                    this.getAggregation("_cameraSelection").addItem(new Item({ key: key, text: camera.name }));
                }.bind(this))
                if (cameras.length > 0) {
                    this.scanner.start(cameras[0]);
                } else {
                    console.error('No cameras found.');
                }
            }.bind(this)).catch(function (e) {
                console.error(e);
            });
        },
        onQRCodeScanned: function (qrcode) {
            // this.setValue(qrcode);
            //use setproperty with suppressinvalidate true to avoid rerender of control
            this.setProperty("value", qrcode, true);
            this.fireQRCodeScanned({
                value: qrcode
            });
        },
        onChangeCamera:function(event){
            this.scanner.start(this.cameras[event.getParameter("selectedItem").getKey()]);
        }
    });
});
