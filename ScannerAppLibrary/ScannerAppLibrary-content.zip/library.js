/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"be.wl.ScannerAppLibrary",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["be.wl.ScannerAppLibrary.controls.QRScanner"],elements:[]});return be.wl.ScannerAppLibrary},false);